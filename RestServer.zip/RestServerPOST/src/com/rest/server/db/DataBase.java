package com.rest.server.db;


import java.util.HashMap;
import java.util.Map;

import com.rest.server.employees.Employee;

public class DataBase {
	
	private static Map<Long, Employee> employeeList = new HashMap<Long, Employee>();
	
	public static Map<Long, Employee> getEmployeeList(){
		return employeeList;
	}
}
