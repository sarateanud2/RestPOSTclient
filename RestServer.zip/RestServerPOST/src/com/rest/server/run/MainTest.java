package com.rest.server.run;

import com.rest.server.employees.Employee;
import com.rest.server.resources.EmployeeResources;

public class MainTest {

	public static void main(String[] args) {
		EmployeeResources employeeResources = new EmployeeResources();
		
		System.out.println(employeeResources.getEmployees() + "\n");
		System.out.println("\n\n\n");
		Employee em1 = new Employee("Maria", "Sochina", 5000);
		employeeResources.addEmployee2(em1);
		System.out.println(employeeResources.getEmployees() + "\n");

	}

}
