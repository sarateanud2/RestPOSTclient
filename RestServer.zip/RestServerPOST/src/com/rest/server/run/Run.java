package com.rest.server.run;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("run")
public class Run extends Application{

}
