package com.rest.server.requests;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.rest.server.employees.Employee;
import com.rest.server.resources.EmployeeResources;

@Path("/employee")
@Produces(MediaType.APPLICATION_JSON)
public class EmployeeRequests {
	
	private EmployeeResources employeeResources = new EmployeeResources();
	
	@GET
	@Path("/allemployees")
	public List<Employee> getEmployee(){
		return employeeResources.getEmployees();
	}
	
	/*@GET
	@Path("/{salaryId}")
	public List<Employee> getEmployeSal(@PathParam("salaryId") int sal){
		return employeeResources.getEmployeeBiggerSal(sal);
	}
	
	@GET
	@Path("/salary/{lowerSal}")
	public List<Employee> getEployeeSalLower(@PathParam("lowerSal") int sal){
		return employeeResources.getEmployeeLowerSal(sal);
	}*/
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public Employee addEmployeeServ(Employee employee){
		
		return employeeResources.addEmployee2(employee);
	}
}
