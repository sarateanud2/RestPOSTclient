package com.rest.server.resources;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import com.rest.server.employees.Employee;

public class InitEmployeeParam {
	
	
	
	public List<Employee> getAllEployees(){
		Employee em1 = new Employee("Dumitru", "Sarateanu", 80000);
		Employee em2 = new Employee("Andrei", "Sarateanu", 50000);
		Employee em3 = new Employee("Andrei", "Morari", 4000);
		Employee em4 = new Employee("Arcadie", "Morari", 9000);
		Employee em5 = new Employee("Marin", "Cucu", 6000);
		Employee em6 = new Employee("Anna", "Dobri", 6000);
		Employee em7 = new Employee("Rodica", "Mocreac", 5000);
		List<Employee> list = new ArrayList<>();
		list.addAll(Arrays.asList(new Employee[] {em1, em2, em3, em4, em5, em6, em7}));
		
		return list;
	}
	
	/*private Map<Long, Employee> employeeMap;

	public InitEmployeeParam() {
		
		employeeMap = new HashMap<Long, Employee>();
		employeeMap.put(1L, new Employee("Dumitru", "Sarateanu", 80000));
		employeeMap.put(2L, new Employee("Andrei", "Sarateanu", 50000));
		employeeMap.put(3L, new Employee("Andrei", "Morari", 4000));
		employeeMap.put(4L, new Employee("Arcadie", "Morari", 9000));
		employeeMap.put(5L, new Employee("Marin", "Cucu", 6000));
		employeeMap.put(6L, new Employee("Anna", "Dobri", 6000));
		employeeMap.put(7L, new Employee("Rodica", "Mocreac", 5000));
	}*/
	
	
}
