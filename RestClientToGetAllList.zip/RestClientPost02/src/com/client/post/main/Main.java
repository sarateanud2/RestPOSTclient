package com.client.post.main;

import java.util.List;

import com.client.post.employee.Employee;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.GenericType;

public class Main {

	public static void main(String[] args) {
		
//		Client client = Client.create();
		
		List<Employee> employeeList = Client.create().resource("http://localhost:8080/RestServerPOST/run/employee/allemployees").get(new GenericType<List<Employee>>(){});
		int i = 0;
		for (Employee employee : employeeList) {
			System.out.printf("Employee nr. %d:\n", ++i);
			System.out.printf("First name: %s \n", employee.getFname());
			System.out.printf("Last name: %s \n", employee.getLname());
			System.out.printf("Salary: %d \n", employee.getSalary());
			System.out.println("");
		}
	}

}
