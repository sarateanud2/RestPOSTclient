package com.client.post.main;

import java.util.List;

import javax.ws.rs.core.MediaType;

import com.client.post.employees.Employee;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;


public class Main {

	public static void main(String[] args) {
		
		try{
			Employee employee = new Employee();
			employee.setFname("Ion");
			employee.setLname("Turcanu");
			employee.setSalary(3500);
			
			Client client = Client.create();
			
			WebResource webResource = client.resource("http://localhost:8080/RestServerPOST/run/employee");
			
			ClientResponse response = webResource.accept(MediaType.APPLICATION_JSON).post(ClientResponse.class, employee);
			
			Employee em1 = response.getEntity(Employee.class);
			System.out.println(em1);
			
			if (response.getStatus() != 200) {
				   throw new RuntimeException("Failed : HTTP error code : " + response.getStatus());
			}
			
			List<Employee> listEmployee = Client.create().resource("http://localhost:8080/RestServerPOST/run/employee/allemployees").get(new GenericType<List<Employee>>(){});
			
			System.out.println("Output from Server .... \n");
			System.out.println(listEmployee);
			
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

}
